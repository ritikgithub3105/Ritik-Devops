# Jenkins_Batch_28
Contains assignment of Jenkins 
